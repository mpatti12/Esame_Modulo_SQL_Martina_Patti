-- Creazione DataBase ToysGroup.
CREATE DATABASE ToysGroup;

USE ToysGroup;

-- Creo le tabelle.
CREATE TABLE Product (
	ProductId INT PRIMARY KEY,
    ProductName VARCHAR (100),
    Category VARCHAR(100),
    UnitPrice DECIMAL (50, 2),
    Age VARCHAR(100) );
    
    
   CREATE TABLE Region (
    RegionID INT PRIMARY KEY,
    RegionName VARCHAR(50),
    Country VARCHAR(50),
    ShippingMethod VARCHAR(50));
    
    
    CREATE TABLE Sales (
    SalesID INT PRIMARY KEY,
    SalesAmount DECIMAL (50, 2),
    TransactionDate DATE,
    Quantity INT,
    ProductId INT,
    RegionId INT,
	FOREIGN KEY (ProductId) REFERENCES Product(ProductId),
    FOREIGN KEY (RegionId) REFERENCES Region(RegionId)
);

-- popolo le tabelle.
INSERT INTO Product (ProductID, ProductName, Category, UnitPrice, Age) VALUES
(1, 'Palla da Calcio', 'Sport', 25.99, '4+'),
(2, 'Bicicletta senza Pedali', 'Esterno', 105.99, '3+'),
(3, 'Piscina Gonfiabile', 'Esterno', 79.99, '3+'),
(4, 'Set Trucchi', 'Arte', 9.99, '4+'),
(5, 'Aquilone', 'Esterno', 19.99, '7+'),
(6, 'Tenda Indiani', 'Avventura', 69.99, '6+'),
(7, 'Elicottero Telecomandato', 'Elettronica', 129.99, '5+'),
(8, 'Bambole', 'Bambole', 49.99, '3+'),
(9, 'Set da Beach Volley', 'Spiaggia', 39.99, '6+'),
(10, 'Skateboard', 'Esterno', 99.99, '8+');

INSERT INTO Region (RegionID, RegionName, Country, ShippingMethod) VALUES
(301, 'Italia', 'Europa', 'Mare'),
(302, 'Stati Uniti', 'Nord America', 'Aereo'),
(303, 'Francia', 'Europa', 'Terra'),
(304, 'Cina', 'Asia', 'Mare'),
(305, 'Germania', 'Europa', 'Aereo'),
(306, 'Brasile', 'Sud America', 'Terra'),
(307, 'Spagna', 'Europa', 'Mare'),
(308, 'Giappone', 'Asia', 'Aereo'),
(309, 'Regno Unito', 'Europa', 'Terra'),
(310, 'Australia', 'Oceania', 'Mare');

INSERT INTO Sales(SalesID, SalesAmount, TransactionDate, Quantity, ProductId, RegionId) VALUES 
(1, 129.95, '2024-03-01', 5, 1, 301),
(2, 211.98, '2024-03-02', 2, 2, 302),
(3, 319.96, '2024-03-03', 4, 3, 303),
(4, 89.91, '2024-03-04', 9, 4, 304),
(5, 119.99, '2024-03-05', 6, 5, 301),
(6, 69.99, '2024-03-06', 1, 6, 305),
(7, 259.98, '2024-03-07', 2, 7, 303),
(8, 149.97, '2024-03-08', 3, 8, 303);


-- Richieste

-- 1) Verificare che i campi definiti come PK siano univoci:

SELECT ProductID AS PrimaryKey, COUNT(ProductID) AS ProductID_UNIVOCO
FROM Product
GROUP BY ProductID
HAVING COUNT(ProductID) > 1;

SELECT RegionID AS PrimaryKey, COUNT(RegionID) AS RegionID_UNIVOCO
FROM Region
GROUP BY RegionID
HAVING COUNT(RegionID) > 1;

SELECT SalesID AS PrimaryKey, COUNT(SalesID) AS SalesID_UNIVOCO
FROM Sales
GROUP BY SalesID
HAVING COUNT(SalesID) > 1;


-- 2) Esporre l’elenco dei soli prodotti venduti e per ognuno di questi il fatturato (quantita e costo) totale per anno.

SELECT P.ProductId, P.ProductName, YEAR(Vendite.TransactionDate) as SalesYear, SUM(Vendite.SalesAmount) as Fatturato
FROM Sales as Vendite
INNER JOIN Product as P ON Vendite.ProductId = P.ProductId
GROUP BY P.ProductName, YEAR(Vendite.TransactionDate), P.ProductId;


-- Esporre il fatturato totale per stato per anno. Ordina il risultato per data e per fatturato decrescente. 

SELECT r.RegionId, r.Country, SUM(s.SalesAmount) as Fatturato, YEAR(s.TransactionDate) as Anno_di_Fatturazione
FROM Salesa as s
INNER JOIN Region r ON s.RegionId = r.RegionId
INNER JOIN Product p ON s.ProductId = p.ProductId
GROUP BY SalesYear, r.RegionId
ORDER BY Anno_di_Fatturazione DESC, Fatturato DESC;


-- 3) Rispondere alla seguente domanda: qual è la categoria di articoli maggiormente richiesta dal mercato?

SELECT p.Category, SUM(s.Quantity) as Quantità_Totale_Articoli_Richiesti
FROM Sales as s
INNER JOIN Product as p ON s.ProductId = p.ProductID
GROUP BY p.Category
ORDER BY Quantità_Totale_Articoli_Richiesti DESC
LIMIT 1;

-- 5) Rispondere alla seguente domanda: quali sono, se ci sono, i prodotti invenduti? Proponi due approcci risolutivi differenti. 
-- Approccio n1

SELECT p.ProductId, p.ProductName
FROM Product as p 
WHERE p.ProductId NOT IN
(SELECT Distinct s.ProductId FROM Sales as s);

-- Approccio n2

SELECT p.ProductId, p.ProductName
FROM Product as p 
LEFT JOIN Sales as s ON p.ProductId = s.ProductId
WHERE s.ProductId IS NULL;

-- Esporre l’elenco dei prodotti con la rispettiva ultima data di vendita (la data di vendita più recente).

SELECT 
    p.ProductName, MAX(s.TransactionDate) AS Ultima_Vendita
FROM
    Product AS p
        INNER JOIN
    Sales AS s ON p.ProductId = s.ProductId
GROUP BY p.ProductName;